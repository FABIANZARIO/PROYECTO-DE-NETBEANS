/*
 FABIAN YAHVE PEÑA PEREZ 23580065 05-11-23
*PRACTICA 16 PSeint a JavaNetBeans
*Seguro de un trabajador
 */
package com.mycompany.practica_pseint_17;

import java.util.Scanner;

public class Practica_PSeint_17 {

    public static void main(String[] args) {
        Scanner Scanner = new Scanner (System.in);
        System.out.println("Tiene seguro social? \n1=SI \n2=NO \n");
        int SS = Scanner.nextInt();
        System.out.println("Tiene seguro medico? \n1=SI \n2=NO \n");
        int SM = Scanner.nextInt();
        if (SS == 1 && SM == 1) {
            System.err.println("Usted no pagara por su consulta");
        } 
        else if (SS == 1) {
            System.err.println("Usted solo pagara el 60% de su consulta");
        }
        else if (SM == 1) {
            System.err.println("Usted solo pagara el 30% de su consulta");
        }
        else if (SS == 2 && SM == 2) {
            System.err.println("Usted tendra que pagar toda su consulta");
        }
    }
}
